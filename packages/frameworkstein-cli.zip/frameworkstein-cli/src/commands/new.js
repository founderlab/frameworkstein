import createFolderStructure from '../lib/createFolderStructure'

export default function newApp(_options, _callback) {

  createFolderStructure(_options, _callback)

}

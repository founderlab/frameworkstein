
## [Unreleased]
  - v2.0 started

## [1.1.3]
  - Updated controller template

## [1.1.0]
  - Controller template uses `fl-backbone-rest`

## [1.0.6]
  - Updated some templates. The `created_at` default is now `createdDate`

## [1.0.4]
  - Add model command updated to include a base template

## [1.0.3]
  - Variables now camelCase by default
  - `new` commands added thanks to @hengji-liu
    - `fl new-web appname`: Create a new web app
    - `fl new-mobile appname`: Checkout the src of a base mobile app with react-native

## [0.3.3]
 - models use smartSync

## [0.3.2]
 - controllers auth method fix

## [0.3.0]
 - controllers auth method allows only `GET` by default

## [0.2.0]
 - fixed path to model in controllers

## [0.1.0]
 - add_model uses PascalCase for class+controller filenames

## [0.0.1]
 - fl add_model initial implementation

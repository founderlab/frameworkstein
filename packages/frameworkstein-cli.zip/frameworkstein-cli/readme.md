# FounderLab command line interface

#### Usage:

`npm i -g frameworkstein`

`fl add-model ModelName`
or `fl m ModelName`

`fl new-web appname`

`fl new-mobile appname`
